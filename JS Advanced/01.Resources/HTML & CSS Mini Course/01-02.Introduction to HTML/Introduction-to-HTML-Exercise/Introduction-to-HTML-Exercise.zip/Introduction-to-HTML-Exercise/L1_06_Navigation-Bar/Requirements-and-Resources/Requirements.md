﻿# 05 - Table
------
Problems for homework for the [“HTML and CSS Basics”](#) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/#!/List/ByCategory/165/HTML-and-CSS)

## Constraints
* Change the document **title**
* Use **nav** tag to create a navigation
    * Use **ul** tag to create an unordered list
    * Create **list items** with **hyperlinks** inside them for each menu item
	
## Hints
* You can try to write some **CSS** for better looking navigation bar *(see the provided screenshots)*