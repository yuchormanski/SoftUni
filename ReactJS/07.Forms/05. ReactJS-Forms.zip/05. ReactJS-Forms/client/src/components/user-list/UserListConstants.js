export const UserActions = {
    Details: 'details',
    Edit: 'edit',
    Delete: 'delete',
    Add: 'add',
};
