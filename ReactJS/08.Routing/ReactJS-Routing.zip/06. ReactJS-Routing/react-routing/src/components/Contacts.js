const Contacts = () => {
    return (
        <h2>Contacts Page</h2>
    );
};

export default Contacts;
