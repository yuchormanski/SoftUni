const Pricing = () => {
    return (
        <h2>Pricing Page</h2>
    );
};

export default Pricing;
