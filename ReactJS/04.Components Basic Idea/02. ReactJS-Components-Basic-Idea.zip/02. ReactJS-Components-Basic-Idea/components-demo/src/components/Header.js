import React from 'react';

export const Header = (props) => {
    const reactElement = <h1>{props.children}</h1>;
    
    return reactElement;
};
