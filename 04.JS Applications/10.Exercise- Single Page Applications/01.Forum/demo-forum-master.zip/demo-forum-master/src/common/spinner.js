import { html } from '../lib.js';


export const spinner = () => html`<p class="spinner">Loading &hellip;</p>`;