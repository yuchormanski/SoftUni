const logout = document.querySelector('nav #user').style.display = 'none';
