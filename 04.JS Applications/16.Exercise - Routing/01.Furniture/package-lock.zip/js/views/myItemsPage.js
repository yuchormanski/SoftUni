import {html} from '../../node_modules/lit-html/lit-html.js';


export async function mayItemsPage(ctx){
    console.log('mayItemsPage');
}