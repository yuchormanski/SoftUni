import { initialize } from "./templates.js";


initialize()
