function colorize() {
    // TODO
}