function showText() {
    // TODO
}