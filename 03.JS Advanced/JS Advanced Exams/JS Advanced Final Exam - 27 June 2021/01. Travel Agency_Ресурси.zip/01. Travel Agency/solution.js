window.addEventListener('load', solution);

function solution() {
  console.log('TODO: Write the missing functionality!');
}
