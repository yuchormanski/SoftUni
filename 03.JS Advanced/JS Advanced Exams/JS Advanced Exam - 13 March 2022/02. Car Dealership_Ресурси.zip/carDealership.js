class CarDealership {

}