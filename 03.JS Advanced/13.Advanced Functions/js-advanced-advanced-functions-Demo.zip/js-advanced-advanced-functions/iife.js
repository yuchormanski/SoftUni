(function print() {
    console.log('Hello World');
})();
